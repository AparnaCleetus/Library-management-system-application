<html>
<head><title></title></head>
<body>
<center>
<form action=bookreturn.php method="post">
<h2>Input your search string: <INPUT TYPE=text NAME="input_string" ID="input_string"><BR><BR></h2>
<h1><input type="submit" value="Submit"><BR><BR></h1>
<center><h2><a href="home.php">HOME</a></h2></center>
</center>
</form>
</body>
</html>