<?php
echo '<center><h1>Book Details</h1></center>';
echo '<table width=100% cellpadding=10 cellspacing=10 border=5 bordercolor="blue">';
echo '<tr>

<th>ISBN
<th>BOOK_TITLE
<th>AUTHOR
<th>AVAILABILITY
</tr>';

$connection=mysqli_connect('localhost','root') or die('unable to connect');
#echo 'select the database';
mysqli_select_db($connection,"library");
#get the value from html form
$input=explode(" ",$_POST['input_string']);
foreach($input as $string){
	$query="select B.ISBN,B.TITLE,A.NAME,B.AVAILABLE from BOOK B,BOOK_AUTHOR BA, AUTHORS A where B.ISBN=BA.ISBN and BA.AUTHOR_ID=A.AUTHOR_ID and (B.ISBN = '$string' OR B.TITLE like '%$string%' OR  A.NAME like '%$string%')";
	$result=mysqli_query($connection,$query);
	if((mysqli_num_rows($result))!=0)
	{
		
	while($row=mysqli_fetch_row($result))
		{
		$rows[] = $row;
		echo '<tr>';
		
		echo '<td><center>'.$row[0].'</td>';
		echo '<td>'.$row[1].'</td>';
		echo '<td><center>'.$row[2].'</td>';
		if($row[3] == 1){
			
			echo '<td><form action=checkout.php method="post"><button name="checkout" value= "'. $row[0].'"type="submit">Checkout<BR><BR></td>';
          
			}
		else
			echo '<td><center>'."NO".'</td>';
		}
	

	}
    
	else { 
		echo 'RECORD NOT found'; 
		}
	}
echo '</table><center><h1><a href="book.php"> BACK</a></h1></center>';

 
