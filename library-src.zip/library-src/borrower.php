<html>
<head>
<script>
function myFunction() {
	var ssn = document.myform.ssn.value;
	var reg = /[0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]/;
 if(  ssn == "" ) {
            alert( "SSN is mandatory!" );
            document.myform.ssn.focus() ;
            return false;
         }

if(ssn.match(reg) == null) {
            alert( "SSN is invalid" );
            document.myform.ssn.focus() ;
            return false;
         }
		       
if( document.myform.name.value == "" ) {
            alert( "Name is mandatory!" );
            document.myform.name.focus() ;
            return false;
         }	
         
if( document.myform.add.value == "" ) {
            alert( "Address is mandatory!" );
            document.myform.add.focus() ;
            return false;
         }	
}
</script>
</head>
<body>
<center><h1>Borrower Details</h1>
<table width=100% cellpadding=10 cellspacing=10 border=5 bordercolor="blue">
 <form method='POST' action="" name = "myform" onsubmit=return(myFunction());>
 <h2>SSN in the format (nnn-nn-nnnn): <INPUT TYPE=text NAME='ssn' ID='ssn'><br></h2>
 <tr><h2>Name:<INPUT TYPE=text NAME='name' ID='name'><BR></h2></tr>
 <h2>Address: <INPUT TYPE=text NAME='add' ID='add'><BR></h2>
 <h2>Phone :<INPUT TYPE=text NAME='phone' ID='phone'><BR></h2> <BR></h2> 
 <h2><input type='submit' name='submit' ></h2>
</table>
</center>	
</form>


<?php
if(isset($_POST['submit']))
{
	$connection=mysqli_connect('localhost','root') or die('unable to connect');
	mysqli_select_db($connection,"library");
	$ssn = $_POST['ssn'];
	$name = $_POST['name'];
	$add = $_POST['add'];
	$phone = $_POST['phone'];
    $query = "select * from borrower where ssn = '$ssn' ";
	$result=mysqli_query($connection,$query);
	if($result && mysqli_num_rows($result))
	{
		echo "Borrower already ownes a card";	
     }
	else
	{
     if($phone != null)
		{
			 $query1 = "insert into borrower(ssn,bname,address,phone) values('$ssn','$name','$add','$phone')";
		}
		else
		{
			$query1 = "insert into borrower(ssn,bname,address) values('$ssn','$name','$add')";
		}
		$result1=mysqli_query($connection,$query1);
		if($result1)
		{
			echo ("New Borrower has been created");
		}
    }
}
?>

</table><center><h2><a href="home.php">HOME</a></h2></center>
</body>
</html>
