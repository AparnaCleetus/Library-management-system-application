<?php
echo "<html>
<head><title>Check in</title></head>
<body>
<center>
<h1>CHECK IN</h1>
<form method='POST' action=''>
<h2>Input your search string:(ISBN/CARD_NO/BORROWER_NAME) <INPUT TYPE=text NAME='input_string' ID='input_string'><BR><BR></h2>
<input type='submit' name='submit'><BR><BR>
</center>
</form>
";

if(isset($_POST['submit']))
{
	$connection=mysqli_connect('localhost','root') or die('unable to connect');
	mysqli_select_db($connection,"library");
	$input=explode(" ",$_POST['input_string']);	
	echo '<center><h1>Loan details</h1></center>';
	echo '<table width=100% cellpadding=10 cellspacing=10 border=5 bordercolor="blue">';
	echo '<tr><th>LOAN_ID
<th>ISBN
<th>CARD_ID
<th>BORROWER_NAME
<th>STATUS
</tr>';
	foreach($input as $string){
					$query1 = "select bl.loan_id,bl.isbn,bl.card_id,b.bname,bl.date_in from book_loans bl,borrower b where (bl.card_id='$string' OR bl.isbn='$string' OR b.bname = '$string') and bl.card_id=b.card_id" ;
					$result=mysqli_query($connection,$query1);
					if((mysqli_num_rows($result))!=0){
					while($row=mysqli_fetch_row($result))
					{
					echo '<tr>';
					echo '<td><center>'.$row[0].'</td>';
					echo '<td><center>'.$row[1].'</td>';
					echo '<td><center>'.$row[2].'</td>';
					echo '<td><center>'.$row[3].'</td>';
		
					if($row[4] == NULL)
					{
					echo '<td><form action=checkinupdate.php method="post"><button name="checkout" value= "' . $row[0]." ".$row[1]. ' type="submit">Checkin<BR><BR></td>';
					echo '</tr>';
					}
					else
					{
					 echo '<td>Checked in</td></tr>';
					}
					}
				}
				else
				{
					echo "No records were found";
				}
			}
}		
?>
</table><center><h2><a href="home.php">HOME</a></h2></center></body></html>

