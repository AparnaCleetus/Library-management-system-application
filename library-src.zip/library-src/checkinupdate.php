<?php

$input = explode(" ",$_POST['checkout']);
$loan_no = $input[0];
$isbn = $input[1];
$connection=mysqli_connect('localhost','root') or die('unable to connect');
mysqli_select_db($connection,"library");
$date = date('Y-m-d');
$query1="update book_loans set date_in='$date' where loan_id = '$loan_no' and date_in IS NULL";
$query2 = "update book set available = true where isbn = '$isbn'";
$result1=mysqli_query($connection,$query1);
$result2=mysqli_query($connection,$query2);

if($result1!=0)
echo "Check in successful";
else
echo "Check in not successful";

?>

<html>
<head><title></title></head>
<body>
<center><h2><a href="checkin.php">BACK</a></h2></center>
</form>
</body>
</html>