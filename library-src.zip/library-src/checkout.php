<html>
<head>
<script>
	function myFunction() {
  var d = new Date();
  var day = d.getDate();
  var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  var month = months[d.getMonth()];
  var year = d.getFullYear();
  document.getElementById("date_out").innerHTML = day + month + year ;
  var due_date = new Date();
  due_date.setDate(due_date.getDate() + 14);
  document.getElementById("date_due").innerHTML = due_date.getDate() + months[due_date.getMonth()] + due_date.getFullYear() ;

}
</script>
</head>
<body>
<?php 
$isbn=$_POST['checkout'];

?>
<center>
<h1> CHECKOUT BOOKS </h1>
<table width=100% cellpadding=10 cellspacing=10 border=5 bordercolor="blue">
 <form method='GET' action="insert.php">
 <h2>ISBN : <?php echo $isbn ?> </h2>
 <h2>Input the borrower card number: <INPUT TYPE=text NAME='card_no' ID='card_no'><BR><BR></h2>
 <h2>DATE_OUT:<h2 id=date_out >  <BR><BR></h2></h2>
 <h2>DATE_DUE: <h2 id=date_due> <BR><BR></h2></h2>
 <input type="hidden" value= "<?php echo $isbn; ?> " name="isbn" id="isbn">
 <script> myFunction() </script>
 <input type='submit' value='CHECKOUT' name = 'checkout'>
</table>
</center>	
</form>
</body>
</html>

