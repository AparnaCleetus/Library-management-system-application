<html>
<head><title></title></head>
<body>
<center>
<h1>FINES</h1><br>
<form action="" method="post">
<input type="submit" name="submit" value= "Refresh"><BR><BR>
</center>
</form>
</body>
</html>

<?php
if(isset($_POST['submit'])) {
	$connection=mysqli_connect('localhost','root') or die('unable to connect');
	mysqli_select_db($connection,"library");
    $query = 'select loan_id, date_out, due_date, date_in from book_loans';
	$result = mysqli_query($connection,$query);
	$today = date('Y-m-d');
	if (mysqli_num_rows($result)!=0)
	{
		while($row=mysqli_fetch_row($result))
		{
	    if($row[3] == null)
		{
			$diff = abs(strtotime($row[2]) - strtotime(date('Y-m-d')));
			
		}
		else{
			$diff = abs(strtotime($row[2]) - strtotime($row[3]));
		
		}
		$years   = ceil($diff / (365*60*60*24)); 
		$months  = ceil(($diff - $years * 365*60*60*24) / (30*60*60*24)); 
		$days    = ceil(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));	
	//	echo $days."\n";
		if($days > 0)
		{ 
			$amt = 0.25*$days;
			$query_check = "select * from fines where loan_id = '$row[0]' AND paid='0'";
			$result1 = mysqli_query($connection,$query_check);
			if($result1 && mysqli_num_rows($result1)){
				$query1 = "update fines set fine_amt=$amt where loan_id = '$row[0]'";
					
			}	
			else
			{
					$query1 = "insert into fines(loan_id,fine_amt,paid) values('$row[0]',$amt,0)";
			}
		
			$result2= mysqli_query($connection,$query1);
			
		}
		}
		}
	}

?>

<html>
<head><title></title></head>
<body>
<center>

<tr> <a href = "paid_fines.php">Click here to view paid fines</a></tr><br>
<tr> <a href = "unpaid_fines.php">Click here to view unpaid fines</a></tr><br>
<h1><a href = "home.php"> HOME </a></h1>

</body>
</html>

