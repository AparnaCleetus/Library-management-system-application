<?php
 $card_no = $_GET['card_no'];
 $isbn = $_GET['isbn'];

$connection=mysqli_connect('localhost','root') or die('unable to connect');
mysqli_select_db($connection,"library");

$query = "select count(*) from book_loans where card_id= '$card_no' and date_in IS NULL";
$result=mysqli_query($connection,$query);
$row=mysqli_fetch_row($result);
if($row[0] >= 3 )
{
	echo "Borrower has already checked out 3 books";
}
else
{
$date = date('Y-m-d');
$ddate = date('Y-m-d', strtotime($date.'+ 14 days')); 
$query= "insert into book_loans(isbn,card_id,date_out,due_date) values('$isbn','$card_no','$date','$ddate')";
$result=mysqli_query($connection,$query);
if($result!=0)
{
echo "Checkout complete";
$query2 = "update book set available = FALSE where isbn =" .$isbn;
mysqli_query($connection,$query2);

}
else
echo "Checkout not successful";

}
 
echo "<html><body><center><h2><a href='home.php'>HOME</a></h2></center></body></html>";
?> 