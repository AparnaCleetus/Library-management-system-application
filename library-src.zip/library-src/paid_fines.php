<?php
echo '<center><h1>Paid Fines</h1></center>
<table width=100% cellpadding=10 cellspacing=10 border=5 bordercolor="blue">
<tr>
<th>CARD_NO
<th>BORROWER NAME
<th>FINE AMOUNT
<th>PAID STATUS
</tr>';
$connection=mysqli_connect('localhost','root') or die('unable to connect');
$query = "select bl.card_id,b.bname,sum(f.fine_amt),f.paid from fines f, book_loans bl, borrower b where b.card_id = bl.card_id and bl.loan_id = f.loan_id and f.paid = 1 group by bl.card_id"; 
mysqli_select_db($connection,"library");
$result=mysqli_query($connection,$query);
if((mysqli_num_rows($result))!=0)
{
	while($row=mysqli_fetch_row($result))
	{
		echo '<tr>';
		echo '<td>'.$row[0].'</td>';
		echo '<td>'.$row[1].'</td>';
		echo '<td>'.$row[2].'</td>';
		echo '<td>'.$row[3].'</td>';
	}
}
echo "</table><center><h1><a href='fines.php'> BACK </a></h1><center>";
?>

