<?php
echo '<center><h1>Unpaid Fines</h1></center>
<table width=100% cellpadding=10 cellspacing=10 border=5 bordercolor="blue">
<tr>
<th>CARD_NO
<th>BORROWER NAME
<th>FINE AMOUNT
<th>PAID STATUS
</tr>';
$query_fine = "select bl.loan_id,bl.card_id,b.bname,sum(f.fine_amt),f.paid from  fines f, book_loans bl, borrower b where b.card_id = bl.card_id and bl.loan_id = f.loan_id and f.paid = 0 group by bl.card_id"; 
$connection=mysqli_connect('localhost','root') or die('unable to connect');
mysqli_select_db($connection,"library");
$result=mysqli_query($connection,$query_fine);
if((mysqli_num_rows($result))!=0)
{
	while($row=mysqli_fetch_row($result))
	{
		echo '<tr>';
		echo '<td>'.$row[1].'</td>';
		echo '<td>'.$row[2].'</td>';
		echo '<td>'.$row[3].'</td>';
		echo '<td><form action="" method="post"><input type="hidden" value= "' . $row[0]. '" name="loan" id="loan"><input type="submit" value="CLICK TO PAY" name="PAY" ><BR><BR></td>';
	
	}
}

if(isset($_POST['PAY']))
{
	$loan = $_POST['loan'];
	$connection=mysqli_connect('localhost','root') or die('unable to connect');
	mysqli_select_db($connection,"library");
	$query = "update fines set paid=1 where loan_id = $loan"; 
	$result=mysqli_query($connection,$query);
}
echo "</table><center><h1><a href='fines.php'> BACK </a></h1><center>";
?>

